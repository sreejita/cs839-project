We extracted company names from Bloomberg News articles.
Examples:
1) Coca-Cola Co
2) Amerigroup Corp
3) Time Warner Cable Inc
The company names in the documents were manually marked up using the tags <markup> and </markup>